#include "search_server.h"
#include "iterator_range.h"

#include <algorithm>
#include <iterator>
#include <sstream>
#include <iostream>
#include <numeric>

vector<string> SplitIntoWords(const string &line)
{
  istringstream words_input(line);
  return {istream_iterator<string>(words_input), istream_iterator<string>()};
}

SearchServer::SearchServer(istream &document_input)
{
  UpdateDocumentBase(document_input);
}

void SearchServer::UpdateDocumentBase(istream &document_input)
{
  // InvertedIndex new_index;
  for (size_t i = 0; i != maxDocumentsCount; ++i)
  {
    for (size_t j = 0; j != maxWordsCount; ++j)
      index[i][j] = 0;
  }

  for (string current_document; getline(document_input, current_document);)
  {
    Add(current_document);
    //    new_index.Add(move(current_document));
  }

  //  std::swap(index, new_index);
}

void SearchServer::AddQueriesStream(
    istream &query_input, ostream &search_results_output)
{
  for (string current_query; getline(query_input, current_query);)
  {
    std::set<word_t, std::set<docid_t>> documents;
    for (const auto &word : SplitIntoWords(current_query))
    {
      const auto wordId = wordsIndex.GetIndex(word);
      words_to_documents[word] = std::move(GetDocumentsContainsWord(wordId));
    }
      for (size_t i = 0; i != docid; ++i)
      {
        index
      }

      for (const size_t docid : index.Lookup(word))
        docid_count[docid]++;
    }

    /* for (string current_query; getline(query_input, current_query);)
  {
    std::vector<size_t> docid_count(index.GetDocsNumber(), 0);

    for (const auto &word : SplitIntoWords(current_query))
    {
      for (const size_t docid : index.Lookup(word))
        docid_count[docid]++;
    }

    vector<size_t> idx(docid_count.size());
    std::iota(idx.begin(), idx.end(), 0);

    auto it = idx.begin();
    std::advance(it, std::min<size_t>(5, docid_count.size()));

    std::partial_sort(idx.begin(), it, idx.end(),
                      [&docid_count](auto lhs, auto rhs) {
                        if (docid_count[lhs] == docid_count[rhs])
                          return lhs < rhs;
                        return docid_count[lhs] > docid_count[rhs];
                      });

    search_results_output << current_query << ":";

    for (size_t i = 0; i != std::min<size_t>(5, idx.size()); ++i)
    {
      size_t hitcount = docid_count[idx[i]];
      if (hitcount != 0)
      {
        search_results_output << " {"
                              << "docid: " << idx[i] << ", "
                              << "hitcount: " << hitcount << '}';
      }
    }
    search_results_output << endl;
  }*/
  }
  /*
void SearchServer::AddQueriesStream(
    istream &query_input, ostream &search_results_output)
{
  for (string current_query; getline(query_input, current_query);)
  {
    const auto words = SplitIntoWords(current_query);

    map<size_t, size_t> docid_count;
    for (const auto &word : words)
    {
      for (const size_t docid : index.Lookup(word))
      {
        docid_count[docid]++;
      }
    }

    vector<pair<size_t, size_t>> search_results(
        docid_count.begin(), docid_count.end());
    sort(
        begin(search_results),
        end(search_results),
        [](pair<size_t, size_t> lhs, pair<size_t, size_t> rhs) {
          int64_t lhs_docid = lhs.first;
          auto lhs_hit_count = lhs.second;
          int64_t rhs_docid = rhs.first;
          auto rhs_hit_count = rhs.second;
          return make_pair(lhs_hit_count, -lhs_docid) > make_pair(rhs_hit_count, -rhs_docid);
        });

    search_results_output << current_query << ':';
    for (auto [docid, hitcount] : Head(search_results, 5))
    {
      search_results_output << " {"
                            << "docid: " << docid << ", "
                            << "hitcount: " << hitcount << '}';
    }
    search_results_output << endl;
  }
}
*/

  // void InvertedIndex::Add(const string &document)
  void SearchServer::Add(const string &document)
  {
    for (auto wordId : AddWordsFromDocument(document))
    {
      ++index[docid][wordId];
    }
    ++docid;
    /*  
  docs.push_back(document);

  const size_t docid = docs.size() - 1;
  for (const auto &word : SplitIntoWords(document))
  {
    index[word].push_back(docid);
  }*/
  }

  std::set<wordId_t> SearchServer::AddWordsFromDocument(const document_t &document)
  {
    std::set<wordId_t> wordIds;
    for (auto &&word : SplitIntoWords(document))
    {
      wordIds.insert(wordsIndex.AddWord(word));
    }
    return wordIds;
  }

  vector<size_t> InvertedIndex::Lookup(const string &word) const
  {
    if (auto it = index.find(word); it != index.end())
    {
      return it->second;
    }
    else
    {
      return {};
    }
  }