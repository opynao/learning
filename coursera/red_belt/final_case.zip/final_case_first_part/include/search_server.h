#pragma once

#include <istream>
#include <ostream>
#include <set>
#include <list>
#include <vector>
#include <map>
#include <string>
#include <array>
using namespace std;

#define LOGF std::cerr << __FUNCTION__ << " " << __LINE__ << std::endl
#define PR(x) std::cerr << #x << " = " << x << std::endl

constexpr size_t maxWordsCount = 15'000;
constexpr size_t maxDocumentsCount = 50'000;
using document_t = std::string;
using wordId_t = size_t;
using docid_t = size_t;

template <size_t INDEX_SIZE>
class WordsIndex
{
public:
  wordId_t AddWord(const std::string &word);
  wordId_t AddWord(std::string &&word);
  wordId_t GetIndex(const std::string &word) const;
};

class InvertedIndex
{
public:
  void Add(const string &document);
  vector<size_t> Lookup(const string &word) const;

  const string &GetDocument(size_t id) const
  {
    return docs[id];
  }
  size_t GetDocsNumber() const
  {
    return docs.size();
  }

private:
    map<string, std::vector<size_t>> index;
    vector<string> docs;
};

class SearchServer
{
public:
  SearchServer() = default;
  explicit SearchServer(istream &document_input);
  void UpdateDocumentBase(istream &document_input);
  void AddQueriesStream(istream &query_input, ostream &search_results_output);
  InvertedIndex GetIndex() const
  {
    return index;
  }

private:
//  InvertedIndex index;
  void Add(const string &document);
  std::set<docid_t> GetDocumentsContainsWord(const wordId_t) const;
  std::set<wordId_t> AddWordsFromDocument(const document_t &document);
  std::array<maxDocumentsCount, std::array<maxWordsCount, wordId_t>> index;
  size_t docid{0};
  WordsIndex<maxWordsCount> wordsIndex;

};

vector<string> SplitIntoWords(const string &line);